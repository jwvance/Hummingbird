#ifndef __PITCH_H__
#define __PITCH_H__
    
#include "fft.h"
#include "device.h"
#define FRAME_LEN 250  //1024
#define SAMPLE_RATE 4000 //8000

#define R_THRES 0.9    
#define LAG_MIN 5
#define LAG_MAX 50
    
/*
 * Sets up the FFT tables to FRAME_LEN size.
 */
//void pitch_init();

/*
 * Calculate the fundamental pitch using FFT.
 * Returns 0.0 on error.
 */
//double pitch_fft(double real[FRAME_LEN], double imag[FRAME_LEN]);

//double pitch_yaapt(double samples[FRAME_LEN]);

double pitch_zero_cross(int16 samples[FRAME_LEN]);

double auto_correlate(int16 samples[FRAME_LEN]);

#endif
