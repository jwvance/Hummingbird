/*******************************************************************************
* File Name: main.c
*
* Version: 1.0
*
* Description:
*  This is source code for the datasheet example of the USBFS component.
*   
* Related Document:
*  Universal Serial Bus Specification Revision 2.0 
*  Universal Serial Bus Device Class Definition for MIDI Devices Release 1.0
*  MIDI 1.0 Detailed Specification Document Version 4.2
*
********************************************************************************
* Copyright 2012-2013, Cypress Semiconductor Corporation. All rights reserved.
* This software is owned by Cypress Semiconductor Corporation and is protected
* by and subject to worldwide patent and copyright laws and treaties.
* Therefore, you may use this software only as provided in the license agreement
* accompanying the software package from which you obtained this software.
* CYPRESS AND ITS SUPPLIERS MAKE NO WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
* WITH REGARD TO THIS SOFTWARE, INCLUDING, BUT NOT LIMITED TO, NONINFRINGEMENT,
* IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE.
*******************************************************************************/

#include <device.h>

#define BUTT1	(0x01u)
#define BUTT2	(0x02u)

/* Identity Reply message */
const uint8 CYCODE MIDI_IDENTITY_REPLY[] = {
    0xF0u,      /* SysEx */
    0x7Eu,      /* Non-Realtime */
    0x7Fu,      /* ID of target device (7F - "All Call") */
    0x06u,      /* Sub-ID#1 - General Information */
    0x02u,      /* Sub-ID#2 - Identity Reply */
    0x7Du,      /* Manufacturer's ID: 7D - Educational Use */
    0xB4u, 0x04u,               /* Family code */
    0x32u, 0xD2u,               /* Model number */
    0x01u, 0x00u, 0x00u, 0x00u, /* Version number */
    /*0xF7         End of SysEx automatically appended */
};

/* Need for Identity Reply message */
extern volatile uint8 USB_MIDI1_InqFlags;
extern volatile uint8 USB_MIDI2_InqFlags;

volatile uint8 usbActivityCounter = 0u;

uint8 csButtStates = 0u;
uint8 csButtStates_old = 0u;
uint8 csButtChange = 0u;
uint8 inqFlags_old = 0u;


/*******************************************************************************
* Function Name: SleepIsr
********************************************************************************
* Summary:
*  The sleep interrupt service routine used to determine the sleep condition.
*  Devices should go into the Suspend state after they see a constant Idle 
*  state on their upstream facing bus lines for more than 3.0 ms. 
*  The device must actually be suspended, drawing only suspend current from the 
*  bus after no more than 10 ms of bus inactivity on all its ports.
*  This ISR is run each 4ms, so after second turn without USB activity, the 
*  device should be suspended.
*
* Parameters:
*  None
*
* Return:
*  None
*
*******************************************************************************/
CY_ISR(SleepIsr)
{
    /* Chech USB activity */
    if( USB_CheckActivity() != 0u ) 
    {
        usbActivityCounter = 0u;
    } 
    else 
    {
        usbActivityCounter++;
    }
    /* Clear Pending Interrupt */
    SleepTimer_GetStatus();
}


void main()
{
    uint8 midiMsg[4];    

    /* Enable Global Interrupts */
    CYGlobalIntEnable;

    /* Start USBFS device 0 with VDDD operation */
    USB_Start(0u, USB_DWR_VDDD_OPERATION); 

    while(1u)
    {
        
        if(USB_IsConfigurationChanged() != 0u) /* Host could send double SET_INTERFACE request */
        {
            if(USB_GetConfiguration() != 0u)   /* Init IN endpoints when device configured */
            {
                MIDI_PWR_Write(0u); /* Power ON CY8CKIT-044 board */
                /* Start ISR to determine the sleep condition */
                Sleep_isr_StartEx(SleepIsr);
                /* Start SleepTimer's operation */
                SleepTimer_Start();
            	/* Enable the output endpoint */
                USB_MIDI_EP_Init();
            }
            else
            {
                SleepTimer_Stop();
            }    
        }        
        
        if(USB_GetConfiguration() != 0u)    /* Service USB MIDI when device configured */
        {
            /* Call this API from UART RX ISR for Auto DMA mode */
            #if(USB_EP_MM != USB__EP_DMAAUTO) 
                USB_MIDI_IN_Service();
            #endif
            /* In Manual EP Memory Management mode OUT_EP_Service() 
            *  may have to be called from main foreground or from OUT EP ISR
            */
            #if(USB_EP_MM != USB__EP_DMAAUTO) 
                USB_MIDI_OUT_EP_Service();
            #endif

            /* Sending an Identity Reply Universal Sysex message back to the computer */
            if((USB_MIDI1_InqFlags & USB_INQ_IDENTITY_REQ_FLAG) != 0u)
            {
                USB_PutUsbMidiIn(sizeof(MIDI_IDENTITY_REPLY), (uint8 *)MIDI_IDENTITY_REPLY, USB_MIDI_CABLE_00);
                USB_MIDI1_InqFlags &= ~USB_INQ_IDENTITY_REQ_FLAG;
            }
            #if (USB_MIDI_EXT_MODE >= USB_TWO_EXT_INTRF)
                if((USB_MIDI2_InqFlags & USB_INQ_IDENTITY_REQ_FLAG) != 0u)
                {
                    USB_PutUsbMidiIn(sizeof(MIDI_IDENTITY_REPLY), (uint8 *)MIDI_IDENTITY_REPLY, USB_MIDI_CABLE_01);
                    USB_MIDI2_InqFlags &= ~USB_INQ_IDENTITY_REQ_FLAG;
                }
            #endif /* End USB_MIDI_EXT_MODE >= USB_TWO_EXT_INTRF */
            
            /* Service Keys */
    		if (SW1_Read() == 0u) 
            {
                csButtStates |= BUTT1;
            }
            else
            {
                csButtStates &= ~BUTT1;
            }
    		if (SW2_Read() == 0u) 
            {
                csButtStates |= BUTT2;
            }
            else
            {
                csButtStates &= ~BUTT2;
            }
            /* Process any button changes */
    		if ((csButtChange = csButtStates ^ csButtStates_old) != 0u) 
            {
    			csButtStates_old = csButtStates;

    			/* All buttons are mapped to Note-On/Off messages */
    			midiMsg[0] = USB_MIDI_NOTE_ON;
    			
    			/* Button 1 */
    			if ((csButtChange & BUTT1) != 0u) 
                {
    				/* Button determines note number */
    				midiMsg[1] = 72u;
    				if (csButtStates & BUTT1)
                    {
                        midiMsg[2] = 100u;		/* Note On */
                    }
    				else
                    {
                        midiMsg[2] = 0u;			/* Note Off */
                    }    
        			/* Put the MIDI Note-On/Off message into the input endpoint */
                    USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
    			}

    			/* Button 2 */
    			if ((csButtChange & BUTT2) != 0u)
                {
    				/* Button determines note number */
    				midiMsg[1] = 76u;
    				if (csButtStates & BUTT2)
                    {
                        midiMsg[2] = 100u;		    /* Note On */
                    }
    				else
                    {
                        midiMsg[2] = 0u;			/* Note Off */
                    }    
        			/* Put the MIDI Note-On/Off message into the input endpoint */
    				USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
                    /* Second Note message */
                    midiMsg[0] = USB_MIDI_NOTE_ON;
                	midiMsg[1] = 72u;
                    if (csButtStates & BUTT2)
                    {
                        midiMsg[2] = 100u;		    /* Note On */
                    }
    				else
                    {
                        midiMsg[2] = 0u;			/* Note Off */
                    }    
        			/* Put the MIDI Note-On/Off message into the input endpoint */
                    USB_PutUsbMidiIn(3u, midiMsg, USB_MIDI_CABLE_00);
    			}
                #if(USB_EP_MM == USB__EP_DMAAUTO) 
                   #if (USB_MIDI_EXT_MODE >= USB_ONE_EXT_INTRF)
                        MIDI1_UART_DisableRxInt();
                        #if (USB_MIDI_EXT_MODE >= USB_TWO_EXT_INTRF)
                            MIDI2_UART_DisableRxInt();
                        #endif /* End USB_MIDI_EXT_MODE >= USB_TWO_EXT_INTRF */
                    #endif /* End USB_MIDI_EXT_MODE >= USB_ONE_EXT_INTRF */            
                    USB_MIDI_IN_Service();
                    #if (USB_MIDI_EXT_MODE >= USB_ONE_EXT_INTRF)
                        MIDI1_UART_EnableRxInt();
                        #if (USB_MIDI_EXT_MODE >= USB_TWO_EXT_INTRF)
                            MIDI2_UART_EnableRxInt();
                        #endif /* End USB_MIDI_EXT_MODE >= USB_TWO_EXT_INTRF */
                    #endif /* End USB_MIDI_EXT_MODE >= USB_ONE_EXT_INTRF */                
                #endif
    		}
        
            /* Check if the Host requested USB Suspend */
            if( usbActivityCounter >= 2u ) 
            {
                MIDI1_UART_Sleep();
                MIDI2_UART_Sleep();
                MIDI_PWR_Write(1u);     /* Power OFF CY8CKIT-044 board */
                
                /*******************************************************************
                * Disable the USBFS block and set DP Interrupt for wake-up 
                * from sleep mode. 
                *******************************************************************/
                USB_Suspend(); 
                /* Prepares system clocks for the Sleep mode */
                CyPmSaveClocks();
                /*******************************************************************
                * Switch to the Sleep Mode for the PSoC 3 or PSoC 5LP devices:
                *  - PM_SLEEP_TIME_NONE: wakeup time is defined by PICU source
                *  - PM_SLEEP_SRC_PICU: PICU wakeup source 
                *******************************************************************/
                CyPmSleep(PM_SLEEP_TIME_NONE, PM_SLEEP_SRC_PICU);
                /* Restore clock configuration */
                CyPmRestoreClocks();
                /* Enable the USBFS block after power down mode */
                USB_Resume();
                
                /* Enable the output endpoint */
                USB_MIDI_EP_Init();
                MIDI_PWR_Write(0u);     /* Power ON CY8CKIT-044 board */
                MIDI1_UART_Wakeup();
                MIDI2_UART_Wakeup();
                usbActivityCounter = 0u; /* Re-init USB Activity Counter*/
            }
        }
    }
}


/* Local processing of USB MIDI out events here */
void USB_callbackLocalMidiEvent(uint8 cable, uint8 *midiMsg) CYREENTRANT
{
    /* Support General System On/Off Message. */
    if(((USB_MIDI1_InqFlags & USB_INQ_SYSEX_FLAG) == 0u) && ((inqFlags_old & USB_INQ_SYSEX_FLAG) != 0u))
    {
        if(midiMsg[USB_EVENT_BYTE0] == USB_MIDI_SYSEX_GEN_MESSAGE)
        {
            if(midiMsg[USB_EVENT_BYTE1] == USB_MIDI_SYSEX_SYSTEM_ON)
            {
                MIDI_PWR_Write(0u); /* Power ON */
            }
            else if(midiMsg[USB_EVENT_BYTE1] == USB_MIDI_SYSEX_SYSTEM_OFF)
            {
                MIDI_PWR_Write(1u); /* Power OFF */
            }
        }
    }
    inqFlags_old = USB_MIDI1_InqFlags;
    cable = cable;
}    


/* [] END OF FILE */
